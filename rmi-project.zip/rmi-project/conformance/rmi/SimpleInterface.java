package conformance.rmi;

import rmi.RMIException;

public interface SimpleInterface
{
    public void testMethod() throws RMIException;
}
